﻿/**
 * Klasa zawierająca długość i szerokość geograficzną. <br />
 * Klasa bazowa większości typów danych.
 */
export class LonLat {
    /**
     * Długośc geograficzna.<br />
     * LONGITUDE to X (południki to linie o tym samym longidute).
     */
    lon: number;

    /**
     * Szerokośc geograficzna.<br />
     * LATITUDE to Y (równoleżniki to linie o tym samym latitude, równik to linia o latitude 0)
     */
    lat: number;

    /**
     * Konstruktor klasy.
     * @param lon               Długość geograficzna.
     * @param lat               Szerokość geograficzna.
     *
     * @returns                 Obiekt o właściwych parametrach.
     */
    constructor(lon: number, lat: number) {
        this.lon = lon;
        this.lat = lat;
    }
}